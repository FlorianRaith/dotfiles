#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
import org.bukkit.plugin.java.JavaPlugin;
/**
 * Plugin main class
 *
 * @author Florian Raith
 */
public final class ${NAME} extends JavaPlugin {

    @Override
    public void onEnable() {

    }

}